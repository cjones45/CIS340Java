
public class ComputeAreaWithConsoleInput {
  public static void main(String[] args) {
   
    
    // A radius
    double radius = 10;

    // Compute area
    double area = radius * radius * 3.14159;

    // Display result
    System.out.println("The area for the circle of radius " +
      radius + " is " + area);
  } 
}
