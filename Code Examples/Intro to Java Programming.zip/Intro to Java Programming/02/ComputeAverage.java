
public class ComputeAverage {
  public static void main(String[] args) {
    
    // Three numbers
    double number1 = 6.7;
    double number2 = 10.16;
    double number3 = 3.2;

    // Compute average
    double average = (number1 + number2 + number3) / 3;

    // Display result
    System.out.println("The average of " + number1 + " " + number2
      + " " + number3 + " is " + average);
  } 
}
