
/** This application program displays Welcome to Java!
 *  in a message dialog box.
 */
import javax.swing.JOptionPane;

public class WelcomeInMessageDialogBox {
  public static void main(String[] args) {
    // Display Welcome to Java! in a message dialog box
    JOptionPane.showMessageDialog(null, "Welcome to CIS 611, Spring 2016!");
  } // end of the main method
} // end of class
