public class TestLoanClass {
  /** Main method */
  public static void main(String[] args) {


    // Enter yearly interest rate
    double annualInterestRate = 8.25;

    // Enter number of years
    int numberOfYears = 4;

    // Enter loan amount
    double loanAmount =  120000.95;

    // Create Loan object
    Loan loan =
      new Loan(annualInterestRate, numberOfYears, loanAmount);

    // Display loan date, monthly payment, and total payment
    System.out.printf("The loan was created on %s\n" +
      "The monthly payment is %.2f\nThe total payment is %.2f\n",
      loan.getLoanDate().toString(), loan.getMonthlyPayment(),
      loan.getTotalPayment());
  }
}
