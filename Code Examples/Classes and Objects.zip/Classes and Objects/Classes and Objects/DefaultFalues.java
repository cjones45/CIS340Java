
public class DefaultFalues {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x; // x has no default value
	    String y; // y has no default value
	    System.out.println("x is " + x); 
	    System.out.println("y is " + y); 

	}

}
