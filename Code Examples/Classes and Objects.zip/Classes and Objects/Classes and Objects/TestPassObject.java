

import javax.swing.JOptionPane;

public class TestPassObject {
  /** Main method */
  public static void main(String[] args) {
    // Create a Circle object with radius 1
    CircleWithPrivateDataFields myCircle = 
      new CircleWithPrivateDataFields(1);

    // Print areas for radius 1, 2, 3, 4, and 5.
    int n = 5;
    printAreas(myCircle, n);

    // See myCircle.radius and times
    String output = "\n" + "Radius is " + myCircle.getRadius() +"\n";
    output+="n is " + n;
    JOptionPane.showMessageDialog(null, output);
  }

  /** Print a table of areas for radius */
  public static void printAreas(
      CircleWithPrivateDataFields c, int times) {
    String output; 
    while (times >= 1) {
      output 	 = "Radius          Radius \t\tArea\n";
      output += c.getRadius() + "                  " + c.getArea();
      JOptionPane.showMessageDialog(null, output);
      c.setRadius(c.getRadius() + 1);
      times--;
    }
  }
}
