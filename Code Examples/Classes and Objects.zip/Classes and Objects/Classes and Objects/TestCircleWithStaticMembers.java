

import javax.swing.JOptionPane;

public class TestCircleWithStaticMembers {
  /** Main method */
  public static void main(String[] args) {
    String output = "Before creating objects\n";
    output+="The number of Circle objects is " +
      CircleWithStaticMembers.numberOfObjects;
    JOptionPane.showMessageDialog(null,output);

    // Create c1
    CircleWithStaticMembers c1 = new CircleWithStaticMembers();

    // Display c1 BEFORE c2 is created
    output = "\nAfter creating c1 \n";
    output+="c1: radius (" + c1.radius +
    	      ") and number of Circle objects (" +
    	      c1.numberOfObjects + ")";
    JOptionPane.showMessageDialog(null,output);

    // Create c2
    CircleWithStaticMembers c2 = new CircleWithStaticMembers(5);

    // Modify c1
    c1.radius = 9;

    // Display c1 and c2 AFTER c2 was created
    output = "\nAfter creating c2 and modifying c1 \n";
    output+="c1: radius (" + c1.radius +
      ") and number of Circle objects (" +
      c1.numberOfObjects + ") \n";
    output+="c2: radius (" + c2.radius +
      ") and number of Circle objects (" +
      c2.numberOfObjects + ")";
    JOptionPane.showMessageDialog(null,output);
    
    
  }
}
