
public class TestHouse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		House obj1 = new House(234,300);
		try {
			House obj2 = (House) obj1.clone();
			System.out.println(obj2.getId());
		} catch (CloneNotSupportedException e) {
			e.printStackTrace();
		}

	}

}
