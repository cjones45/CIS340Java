import java.util.Scanner; 

import javax.swing.JOptionPane;

public class GreatestCommonDivisor {
  /** Main method */
  public static void main(String[] args) {
    
    // Prompt the user to enter two integers
	  String message; 
	    message= "Enter first integer: ";
	        
	    // get the answer from user
	    String input = JOptionPane.showInputDialog(message);
	    
	    // convert answers to int
	    int  n1 =   Integer.parseInt(input);
	    
	    message= "Enter second integer: ";
        
	    // get the answer from user
	    input = JOptionPane.showInputDialog(message);
	    
	    // convert answers to int
	    int  n2 =   Integer.parseInt(input);
	

	    JOptionPane.showMessageDialog(null,"The greatest common divisor for " + n1 +
      " and " + n2 + " is " + getGCD(n1,n2));
  }
  
  public static int getGCD (int num1, int num2){

	    int gcd = 1;
	    int k = 2;
	    while (k <= num1 && k <= num2) {
	      if (num1 % k == 0 && num2 % k == 0)
	        gcd = k;
	      k++;
	    }
	  return gcd;
  }
}
