// http://www.java2s.com/Tutorial
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class MesageDialogWithStringArray {
  public static void main(final String[] args) {
    JFrame parent = new JFrame();

    String multiLineMsg[] = { "Hello,", "World"} ;
    JOptionPane.showMessageDialog(parent, multiLineMsg);
  }
}