//http://www.java2s.com/Tutorial
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class BigValueJOptionpaneDialog {

  public static void main(String[] a) {
    JFrame frame = new JFrame();
    String bigList[] = new String[30];

    for (int i = 0; i < bigList.length; i++) {
      bigList[i] = Integer.toString(i);
    }

    JOptionPane.showInputDialog(frame, "Pick a printer", "Input", JOptionPane.QUESTION_MESSAGE,
        null, bigList, "Titan");

  }

}