//http://www.java2s.com/Tutorial
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JOptionPane;


public class CreateDialogFromOptionPane {
  public static void main(final String[] args) {
    JFrame parent = new JFrame();
    JOptionPane optionPane = new JOptionPane("Continue printing?", JOptionPane.QUESTION_MESSAGE, JOptionPane.YES_NO_OPTION);
    JDialog dialog = optionPane.createDialog(parent, "Manual Creation");
    dialog.setVisible(true);
  }
}