
import javax.swing.JOptionPane;

public class TestVoidMethod {
  public static void main(String[] args) {
	  JOptionPane.showMessageDialog(null,"The grade 78.5 is ");
    printGrade(78.5);

    JOptionPane.showMessageDialog(null,"The grade 59.5 is ");
    printGrade(59.5);
  }

  public static void printGrade(double score) {
    if (score >= 90.0) {
    	 JOptionPane.showMessageDialog(null,'A');
    } 
    else if (score >= 80.0) {
    	 JOptionPane.showMessageDialog(null,'B');
    } 
    else if (score >= 70.0) {
    	 JOptionPane.showMessageDialog(null,'C');
    } 
    else if (score >= 60.0) {
    	 JOptionPane.showMessageDialog(null,'D');
    } 
    else {
      System.out.println('F');
    }
  }
}
