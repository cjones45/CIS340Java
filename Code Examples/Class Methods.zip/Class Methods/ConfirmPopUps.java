//http://www.java2s.com/Tutorial/Java/0240__Swing/ConfirmPopUps.htm
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class ConfirmPopUps {

  public static void main(String[] a) {
    JFrame frame = new JFrame();
    int result = JOptionPane.showConfirmDialog(frame, "Continue printing?");
    // JOptionPane.showInternalConfirmDialog(desktop, "Continue printing?");

    System.out.println(JOptionPane.CANCEL_OPTION == result);
  }

}