
import javax.swing.JOptionPane;


public class Decimal2HexConversion {
  /** Main method */
  public static void main(String[] args) {
    

    // Prompt the user to enter a decimal integer
		  String message; 
		    message= "Enter a decimal number: ";
		        
		    // get the answer from user
		    String input = JOptionPane.showInputDialog(message);
		    
		    // convert answers to int
		    int  decimal =   Integer.parseInt(input);
		
    
		    JOptionPane.showMessageDialog(null,"The hex number for decimal " + 
                decimal + " is " + decimalToHex(decimal));
  }
  
  /** Convert a decimal to a hex as a string */
  public static String decimalToHex(int decimal) {
    String hex = "";
    
    while (decimal != 0) {
      int hexValue = decimal % 16; 
      hex = toHexChar(hexValue) + hex;
      decimal = decimal / 16;
    }
    
    return hex;
  }
  
  /** Convert an integer to a single hex digit in a character */
  public static char toHexChar(int hexValue) {
    if (hexValue <= 9 && hexValue >= 0)
      return (char)(hexValue + '0');
    else  // hexValue <= 15 && hexValue >= 10
      return (char)(hexValue - 10 + 'A');
  }
}
