
//*************************************************************************** 
//*  
//*       CIS 340                  Spring 2023                  Caleb Jones 
//*  
//*                     Programming Assignment: CalebJonesPA02
//* 
//* 				Class description (can be multiple lines) 
//*   		           This is my submission for the PA02 Assignment
//*  
//*  							 :)
//*                             Date Created: 
//*  						  (Feb 1, 2023)
//*                       File Name:  PA02.java
//*  							
//****************************************************************************
package PA;

import javax.swing.JOptionPane;
import javax.swing.JTextArea;

public class PA02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int cont = JOptionPane.YES_OPTION;
		String name = "";
		int custType = 0;
		double energy = 0;
		int month = 1;
		double billAmount;
		final double MONTHLY_BASE_RESIDENT = 6.75;
		final double MONTHLY_BASE_COMMERCIAL = 10.75;
		String output="Name\t\tCustomer Type\t\tEnergy Used\t\tMonth\t\tBill Ammount";
		int noOfCustomers=0;
		int cont1 = JOptionPane.YES_OPTION;
		String custTypeStr; 
		String monthStr = " ";
		double value = 0;
		String custName = null;
		boolean isWinter = true;
		
		//obtain number of customers, unlimited attempts
		
		cont1 = JOptionPane.YES_OPTION;
		while (cont1 == JOptionPane.YES_OPTION) {
		try {	
			
			noOfCustomers=Integer.parseInt(
						JOptionPane.showInputDialog(null,"Enter the number of customers: "));
			
			if (noOfCustomers<1)
				throw new Exception();
			break;
			
		}catch (Exception ex) {
			
			cont1 = JOptionPane.showConfirmDialog(null, "Invalid Customer Number Input?" + "\nWould you like to continue?");
			if (cont1 != JOptionPane.YES_OPTION) 
				System.exit(0);
		
		}//end try-catch	
	}//end while
		
		
	
		String custTypeArr [] = new String[noOfCustomers];
		String [] custNameArr = new String[noOfCustomers];
		String [] custMonthArr = new String[noOfCustomers];
		int [] custMonthNumArr = new int[noOfCustomers];
		double [] energyArr = new double[noOfCustomers];
		double [] billArr = new double[noOfCustomers];
		
		
		
		
		// read customers data and fill the arrays with that data
		for(int i=0;i<noOfCustomers;i++) {
		
		//input customer rate, unlimited attempts
		//To Complete
		while(true) {	
		try {
		custType=Integer.parseInt(
				JOptionPane.showInputDialog(null,
						"Enter Customer Rate: "
						+ "\n1-Resident"
						+ "\n2-Commercial"));
		if(custType!=1 && custType!=2)
			throw new Exception(); //control goes to catch clause
		
		break;
		}
		catch(Exception ex) {
			JOptionPane.showMessageDialog(null, "Invalid Customer Rate."
					+ "\nIt must be 1 or 2");
		}// end catch
		}// end while
		
		// add customer type to the custTypeArr array at index i
		//To Complete
		if (custType == 1)
			custTypeStr = "Resident";
		else 
			custTypeStr = "Commercial";
		
		custTypeArr [i]= custTypeStr;
		
		//Obtain user input customer number, unlimited attempts
		//To Complete
		while(true) {
		try {
		month=Integer.parseInt(JOptionPane.showInputDialog(null,
				"Enter the month (1-12): "));
		if(String.valueOf(month).length()!=1)
			throw new Exception(); //control goes to catch clause
		break;
		}
		catch(Exception ex) {
			JOptionPane.showMessageDialog(null, 
					"Please enter a valid month!",
					"ERROR MESSAGE",JOptionPane.ERROR_MESSAGE);
			
		}// end catch
		}// end while
		 custMonthNumArr [i]= month;
		
		// input customer name, unlimited attempts
		//To Complete
		while(true) {
		custName=JOptionPane.showInputDialog(null,
				"Enter customer name: ");
		if(custName.isEmpty())
			JOptionPane.showMessageDialog(null, 
					"Please enter a valid customer name!\nIt cannot be empty!","ERROR MESSAGE",JOptionPane.ERROR_MESSAGE);
		else
			break;
		}// end while
		custNameArr [i] = custName;
		
				
		// input number of energy, unlimited attempts
		//To Complete
		while(true) {
		try {
			energy=Double.parseDouble(JOptionPane.showInputDialog(
					null, "Enter Electricity Usage: "));
			if(energy < 0) 
				throw new Exception(); // control goes to the catch clause
			
		break;
		} catch (Exception ex){
			JOptionPane.showMessageDialog(null, 
					"Please enter a valid value for electricity used!\n"
					+ "It cannot be negative!","ERROR MESSAGE",
					JOptionPane.ERROR_MESSAGE);
			
		}// end catch
		}// end while
		
			
		// compute customer bill
		
		
		switch (month) {
		case 1: monthStr = "Jan.";
		isWinter = true;
		case 2: monthStr = "Feb.";
		isWinter = true;
		case 3: monthStr = "Mar.";
		isWinter = true;
		case 4: monthStr = "Apr.";
		isWinter = true;
		case 5: monthStr = "May.";
		isWinter = true;
		case 6: monthStr = "Jun.";
		isWinter = false;
		case 7: monthStr = "Jul.";
		isWinter = false;
		case 8: monthStr = "Aug.";
		isWinter = false;
		case 9: monthStr = "Sep.";
		isWinter = false;
		case 10: monthStr = "Oct.";
		isWinter = true;
		case 11: monthStr = "Nov.";
		isWinter = true;
		case 12: monthStr = "Dec.";
		isWinter = true;
		}
		custMonthArr [i]= monthStr;
		
		switch (custType) {
		case 1: if (energy > 0 && isWinter==true)
			 			value = MONTHLY_BASE_RESIDENT + 
			 			energy * 0.04604 ;
			 	else if (energy <= 500 && isWinter==false)
			 		value = MONTHLY_BASE_RESIDENT + 
		 				energy * 0.04604 ;
			 	else if(energy > 500 && isWinter==false) 
			 		value = MONTHLY_BASE_RESIDENT + 
	 				energy * 0.04604 + ((energy-500)*0.09000);
										
				break;
		case 2: if (energy >= 0 && isWinter ==true)
				 	value = MONTHLY_BASE_COMMERCIAL + (energy * 0.03920); 
				else if (energy < 500 && isWinter== false)
					value = MONTHLY_BASE_COMMERCIAL + (energy * 0.06450);
					
		}// end switch
		billArr [i] = value;
		energyArr [i] = energy;
		
		   //To Complete
		   // add value to the billArr array and custInfoArr at index i
		
		
			
			
		
		}//end for loop
		//String output="Customer Type\tCustomer Number\tCustomer Name\tGallons\tBill Value";
		
		
	//	
	 //custNumArr 
		//  
		//billArr
		//String output="Name\t\tCustomer Type\t\tEnergy Used\t\tMonth\t\tBill Ammount";
		
		for(int i =0;i<billArr.length;i++) {
			output+= "\n" + " \t\t "+ custNameArr[i] + " \t\t "+  custTypeArr[i] + " \t\t "+ energyArr[i] + " \t\t "+ custMonthArr[i]  + " \t\t "+String.format("%.2f", billArr[i]);
		}
		
		// Display the program output with statistics 
		JOptionPane.showMessageDialog(null,new JTextArea(output),"ELECTRICITY BILL CALCULATOR",JOptionPane.INFORMATION_MESSAGE); 
		
				
	}// end main

}// end class


