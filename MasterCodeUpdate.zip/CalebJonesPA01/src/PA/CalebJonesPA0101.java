//*************************************************************************** 
//*  
//* CIS 340                  Spring 2023                  Caleb Jones 
//*  
//*                     Programming Assignment: PA0101
//*  
//* 				Class description (can be multiple lines) 
//*   		This is my Submission for the PA01 Assignment Part 1.
//*  
//*  							 :)
//*                         Date Created 
//*  						(01/24/2023)
//*                         File Name:  CalebJonesPA01
//*  							
//****************************************************************************
package PA;
import javax.swing.*;

public class CalebJonesPA0101 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		

			
		
		int arDay= 0;
		int arMonth = 0;
		int antiDay = 0;
		int antiMonth = 0;
		int daysLate = 0;
		double fineAmount = 0.0;
		String tempString;
		
		tempString = JOptionPane.showInputDialog("Please enter the actual return date: ");
		arDay= Integer.parseInt(tempString);
		tempString = JOptionPane.showInputDialog("Please enter the actual return month: ");
		arMonth= Integer.parseInt(tempString);
		
		switch(arDay) {
		case 31:
		if(arMonth == 2) {
			JOptionPane.showMessageDialog(null,"Invalid Input, please run this program again to try again.");
			System.exit(0);
		}else if(arMonth == 4) {
			JOptionPane.showMessageDialog(null,"Invalid Input, please run this program again to try again.");
			System.exit(0);
		}else if(arMonth == 6) {
			JOptionPane.showMessageDialog(null,"Invalid Input, please run this program again to try again.");
			System.exit(0);
		}else if(arMonth == 9) {
			JOptionPane.showMessageDialog(null,"Invalid Input, please run this program again to try again.");
			System.exit(0);
		}else if(arMonth == 11) {
			JOptionPane.showMessageDialog(null,"Invalid Input, please run this program again to try again.");
			System.exit(0);
		}
		case 30:
			if(arMonth == 2) {
				JOptionPane.showMessageDialog(null,"Invalid Input, please run this program again to try again.");
				System.exit(0);
			}
		case 29:
			if(arMonth == 2) {
				JOptionPane.showMessageDialog(null,"Invalid Input, please run this program again to try again.");
				System.exit(0);
			}
		}
		tempString = JOptionPane.showInputDialog("Please enter the anticipated return day : ");
		antiDay= Integer.parseInt(tempString);
		tempString = JOptionPane.showInputDialog("Please enter the anticipated return month : ");
		antiMonth= Integer.parseInt(tempString);
		
		//input validation
		
		switch(antiDay) {
		case 31:
		if(antiMonth == 2) {
			JOptionPane.showMessageDialog(null,"Invalid Input, please run this program again to try again.");
			System.exit(0);
		}else if(antiMonth == 4) {
			JOptionPane.showMessageDialog(null,"Invalid Input, please run this program again to try again.");
			System.exit(0);
		}else if(antiMonth == 6) {
			JOptionPane.showMessageDialog(null,"Invalid Input, please run this program again to try again.");
			System.exit(0);
		}else if(antiMonth == 9) {
			JOptionPane.showMessageDialog(null,"Invalid Input, please run this program again to try again.");
			System.exit(0);
		}else if(antiMonth == 11) {
			JOptionPane.showMessageDialog(null,"Invalid Input, please run this program again to try again.");
			System.exit(0);
		}
		case 30:
			if(antiMonth == 2) {
				JOptionPane.showMessageDialog(null,"Invalid Input, please run this program again to try again.");
				System.exit(0);
			}
		case 29:
			if(antiMonth == 2) {
				JOptionPane.showMessageDialog(null,"Invalid Input, please run this program again to try again.");
				System.exit(0);
			}
		}
		if(arDay<0||antiDay<0||arMonth<0||antiMonth<0) {
			JOptionPane.showMessageDialog(null,"Invalid Input, please run this program again to try again.");
			System.exit(0);
		}
		
		
		
		//calculation
		daysLate = arDay-antiDay;
		
		
		if(antiDay >= arDay && antiMonth >= arMonth){
			fineAmount=0;
			
		
	}else if(antiMonth==arMonth && antiDay < arDay) {
		fineAmount = 15*daysLate;
		
	}else if(antiMonth<arMonth && antiDay < arDay) {
		fineAmount = 500 * daysLate;
	}
		
		//output 
		//cents to dollars
		fineAmount = (fineAmount /100);
		JOptionPane.showMessageDialog(null,new JTextArea("Number of days late: " + daysLate + "    \nFine amount: (" + daysLate + " * 15 cents) = " + fineAmount));
		
	
		
			
			
			
		}

		
		
	
	}
	


