//*************************************************************************** 
//*  
//* CIS 340                  Spring 2023                  Caleb Jones 
//*  
//*                     Programming Assignment: PA0102
//*  
//* 				Class description (can be multiple lines) 
//*   		This is my Submission for the PA01 Assignment Part 2.
//*  
//*  							 :)
//*                         Date Created 
//*  						(01/24/2023)
//*                         File Name:  CalebJonesPA01
//*  							
//****************************************************************************
package PA;

import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.*;

public class CalebJonesPA0102 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//PROGRAM 2
				//declare variables 
				double bCoins = 0;
				int transaction = 2;
				double moneySpent = 0.0;
				final double BITCOIN_TO_DOLLAR = 15000;
				final double DOLLAR_TO_BITCOIN = 0.000066666666;
				double output = 0;
				double totalBitcoins;
				String tempString;
			
				
				tempString = JOptionPane.showInputDialog("Number of Bitcoins you own : ");
				bCoins= Double.parseDouble(tempString);
				tempString = JOptionPane.showInputDialog("Choose a transaction type (0: Buy, 1: Sell): ");
				transaction= Integer.parseInt(tempString);
				tempString = JOptionPane.showInputDialog("Amount you wish to spend on buying bitcoins: ");
				moneySpent= Double.parseDouble(tempString);
				
				
				switch (transaction) {
				case 0:
					//buy
					if(moneySpent >= 100) {
						output = moneySpent * DOLLAR_TO_BITCOIN;
						
						
						totalBitcoins = bCoins + output;
						
						JOptionPane.showMessageDialog(null,new JTextArea("Bitcoins for $"+String.format("%.1f",moneySpent) +":  "+String.format("%.3f",output)   +"\nTotal Bitcoins:  " + String.format("%.3f",totalBitcoins) +
								"\nAmount in USD:  $" + String.format("%.2f",totalBitcoins * BITCOIN_TO_DOLLAR)));
						break;
					
						
					}else {
						JOptionPane.showMessageDialog(null,"Invalid Input, please add at least $100.");
						System.exit(0);
					}
					break;
				case 1:
					//withdraw
					if(moneySpent >= 100) {
						totalBitcoins = bCoins - output;
						
						JOptionPane.showMessageDialog(null,new JTextArea("Bitcoins for $"+String.format("%.1f",moneySpent) +":  "+String.format("%.3f",output)   +"\nTotal Bitcoins:  " + String.format("%.3f",totalBitcoins) +
								"\nAmount in USD:  $" + String.format("%.0f",totalBitcoins * BITCOIN_TO_DOLLAR)));
						
						break;
					}else {
						JOptionPane.showMessageDialog(null,"Invalid Input, please add at least $100.");
						System.exit(0);
					}
					
					break;
				default:
					JOptionPane.showMessageDialog(null,"Invalid Input, please run this program again to try again.");
					System.exit(0);
					break;

				}
	}
}


