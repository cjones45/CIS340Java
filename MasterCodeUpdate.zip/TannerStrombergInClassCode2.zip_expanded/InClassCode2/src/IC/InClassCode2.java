package IC;
import javax.swing.*;
import javax.swing.JOptionPane;
public class InClassCode2 {

	public static void main(String[] args) {
		
		String name = "";
		int custType; 
		int cont = JOptionPane.YES_OPTION;
		int minutes;
		
		//input customer name	
		while (cont == JOptionPane.YES_OPTION) {
			name = JOptionPane.showInputDialog(null, "Enter the customer name: ");
			if(name.isEmpty()) {
				//JOptionPane.showMessageDialog(null, "Invalid Customer name, Input" + "\nSystem Exit.");
			
			cont = JOptionPane.showConfirmDialog(null, "Invalid Customer name, Input?" + "\nWould you like to continue?");
			if (cont != JOptionPane.YES_OPTION) 
				System.exit(0);
		}
			else 
				cont = -1;
			//yes option is always 0
			//no is always 1
			//cancel is always 2
	}//end while
		
		cont = JOptionPane.YES_OPTION;
		while (cont == JOptionPane.YES_OPTION) {
		try {	
			
			custType=Integer.parseInt(
						JOptionPane.showInputDialog(null,"Enter customer number: " + "\n0 - Hourly Bill" + "\n1 - Contract Bill"));
			
			if ((custType != 0) && (custType != 1))
				throw new Exception();
			break;
			
		}catch (Exception ex) {
			//JOptionPane.showMessageDialog(null, "Invalid customer type, Input?" + "\nSystem Exit.");
			cont = JOptionPane.showConfirmDialog(null, "Invalid Customer type, Input?" + "\nWould you like to continue?");
			if (cont != JOptionPane.YES_OPTION) 
				System.exit(0);
		
		}//end try-catch	
	}//end while
		
		cont = JOptionPane.YES_OPTION;
		while (cont == JOptionPane.YES_OPTION) {
		try { 
			
			minutes  = Integer.parseInt(JOptionPane.showInputDialog(null, "Enter the number of minutes used:"));
			if (minutes < 0) 
				throw new NumberFormatException();
			break;
			
			} catch (NumberFormatException ex) {
				//JOptionPane.showMessageDialog(null, "Invalid number of minutes, Input?" + "\nSystem Exit.");
				cont = JOptionPane.showConfirmDialog(null, "Invalid number of minutes, Input?" + "\nWould you like to continue?");
				if (cont != JOptionPane.YES_OPTION)
				System.exit(0);
			}//end try - catch
		}//end while
	

		
		
		
		
}
}
