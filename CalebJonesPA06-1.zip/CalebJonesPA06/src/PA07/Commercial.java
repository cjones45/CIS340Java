package PA07;

//add class template

public class Commercial extends ElectricBill{


	// complete the constructor	
	public Commercial(int noOfKWH, int billMonth) { 
		super(noOfKWH,billMonth);
		this.computeBill();
	}

	@Override
	public void computeBill() {
		// compute the bill amount for a commercial customer
		//winter
				if(getBillMonth() != 6 || getBillMonth() != 7 || getBillMonth() != 8 || getBillMonth() != 9) {
					setbillAmount(BASE_COMMERCIAL_CUST + (getnoOfKWH() * 0.03920));
					
				}else if(getBillMonth() == 6 || getBillMonth() == 7 || getBillMonth() == 8 || getBillMonth() == 9) {
					
					
					setbillAmount(BASE_COMMERCIAL_CUST + (getnoOfKWH() * 0.06450));
					
				}
			
		
	}
	
}