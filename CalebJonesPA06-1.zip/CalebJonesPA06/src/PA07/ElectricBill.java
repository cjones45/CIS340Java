
//
package PA07;

//add class template

public abstract class ElectricBill implements BaseCharge{

	
	private int noOfKWH;
	private int billMonth;
	private double billAmount;

	

	public ElectricBill(int noOfKWH,int billMonth) {
		this.noOfKWH = noOfKWH;
		this.setBillMonth(billMonth);
	}
	public ElectricBill(int bill,int noOfKWH,int billMonth) {
		this.noOfKWH = noOfKWH;
		this.setBillMonth(billMonth);
		this.billAmount = bill;
	}



	public int getBillMonth() {
		return billMonth;
	}



	public void setBillMonth(int billMonth) {
		this.billMonth = billMonth;
	}
	public double getbillAmount() {
		return billAmount;
	}



	public void setbillAmount(double billAmount) {
		this.billAmount = billAmount;
	}
	public int getnoOfKWH() {
		return noOfKWH;
	}



	public void setnoOfKWH(int noOfKWH) {
		this.noOfKWH = noOfKWH;
		
	
	
	
	
	// add the toString method

		 
}
}