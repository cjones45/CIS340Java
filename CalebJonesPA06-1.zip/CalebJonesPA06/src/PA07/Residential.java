package PA07;

//add class template

public class Residential extends ElectricBill{


	// complete the constructor	
	public Residential(int kwh,int billMonth) { 
		super(kwh,billMonth);
		this.computeBill();
	}

	@Override
	public void computeBill() {
		// compute the bill amount for a residential customer
		
		//winter
				if(getBillMonth() != 6 || getBillMonth() != 7 || getBillMonth() != 8 || getBillMonth() != 9) {
					setbillAmount(BASE_RESIDENTIAL_CUST + (getnoOfKWH() * 0.04604));
					
				}else if(getBillMonth() == 6 || getBillMonth() == 7 || getBillMonth() == 8 || getBillMonth() == 9) {
					//summer
					if(getnoOfKWH()<=500) {
						setbillAmount(BASE_RESIDENTIAL_CUST + (getnoOfKWH() * 0.04604));
					}else {
						setbillAmount(BASE_RESIDENTIAL_CUST + (getnoOfKWH() * 0.09000));
					}
					
				}
		
	}






}


