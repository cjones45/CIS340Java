package PA07;

// add class template
public class Customer {

	private static int customerID;
	private static String fName;
	private static String lName;
	private static int status;
	private static ElectricBill bill;
	public int numberOfCustomers = 0;
	//for file
	private int billNum = 0;
	
	private int nBill;
	
	

	
	
	
	public Customer(int customerID, String fName, String lName, int status, ElectricBill bill) {
		this.customerID = customerID;
		this.fName = fName;
		this.lName = lName;
		this.status = status;
		this.bill = bill;
		numberOfCustomers++;
	}

	

	// add the class overloaded constructor
//for file 
	public Customer(int customerID, String fName, String lName, int status, int billNum,int month, double kwh) {
		// TODO Auto-generated constructor stub
		this.customerID = customerID;
		this.fName = fName;
		this.lName = lName;
		this.status = status;
		this.billNum = billNum;
		ElectricBill nBill;
		if(status ==0 ) {
			nBill = new Commercial(month, (int)kwh);
		}else {
		 nBill = new Residential(month,(int)kwh);
		}
		customerConverter(customerID,fName,lName,status,nBill);
		
		
		//1:Jan","2:Feb","3:Mar","4:Apr","5:May","6:Jun","7:Jul","8:Aug","9:Sep","10:Oct","11:Nov","12:Dec"
//		if(status == 1) {
//		Commercial.computeBill(kwh,monthNum);
//		}else {
//			Residential.computeBill(kwh,monthNum);
//		}
	}
	
	
	public Customer(int customerID, String fName, String lName, int status,int month, int kwh) {
		// TODO Auto-generated constructor stub
		this.customerID = customerID;
		this.fName = fName;
		this.lName = lName;
		this.status = status;
		ElectricBill nBill;
		if(status ==0 ) {
			nBill = new Commercial(month, (int)kwh);
		}else {
		 nBill = new Residential(month,(int)kwh);
		}
		customerConverter(customerID,fName,lName,status,nBill);
		
	}
	public void customerConverter(int customerID, String fName, String lName, int status, ElectricBill nBill) {
		this.customerID = customerID;
		this.fName = fName;
		this.lName = lName;
		this.status = status;
		this.bill = nBill;
	}



	// add setter and getter methods
	public void setCustomerID(int customerID) {
		this.customerID = customerID;
	}
	public int getCustomerID() {
		return customerID;
	}
	
	public void setFName(String fName) {
		this.fName = fName;
	}
	public String getFName() {
		return fName;
	}
	
	public void setLName(String lName) {
		this.lName = lName;
	}
	public String getLName() {
		return lName;
	}
	
	public void setStatus(int status) {
		this.status = status;
	}
	public int getStatus() {
		return status;
	}
	public void setBill(ElectricBill bill) {
		this.bill = bill;
	}
	public ElectricBill getBill() {
		return bill;
	}
	public int getNumberOfCustomers() {
		return numberOfCustomers;
	}
	
	public void setn(int customerID) {
		this.customerID = customerID;
	}
	public int getnBill() {
		return nBill;
	}
	// override the toString() method



	public static String tostring() {
		return "Customer ID: " + customerID + ", Name: " + fName + " " + lName + "  Status: " + status
				+ "  Bill Amount: " + bill.getbillAmount();
	}


}
