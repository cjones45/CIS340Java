
package PA07;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import java.awt.BorderLayout;
import java.awt.Container;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;


public class UserGUI extends JFrame implements ActionListener {
	
	private static String fileName = "customers2.txt";
	static int filesize = 40;
	private static Customer[] customers = new Customer[filesize];

	
	
	
	// declare all GUI components below
	private JLabel label1;
	  private JLabel label2;
	  private JLabel label3;
	  private JLabel label4;
	  private JTextField field1;
	  private JTextField field2;
	  private JTextField field3;
	  private JTextField field4;
	  private JTextField field5;
	  private JComboBox customerList;
	  private JComboBox monthList;
	  private JButton SubmitButton;
	  private JButton CloseButton;
	  
	
	
	// constructor
	UserGUI(String fileName){
		initComponenet();
	    doTheLayout();
	    
//	    try {
//			readFromFile("customers2.txt");
//		} catch (FileNotFoundException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
	    
		
		SubmitButton.addActionListener( new java.awt.event.ActionListener() {
	        public void actionPerformed(ActionEvent btnSave){
	        	submitButtonClicked();
	            }
	    });
	    
	    CloseButton.addActionListener( new java.awt.event.ActionListener() {
	        public void actionPerformed(ActionEvent btnClose){
	        	closeButtonClicked();
	            }
	    });

	
		
	}
private static int getFileLength(String fileName) {
		// TODO Auto-generated method stub
		return fileName.length();
	}
static void readFromFile(String fileName) throws FileNotFoundException {
		
		// create file object
		File file = new File(fileName);
		
		// create scanner object
		Scanner sc = new Scanner(file);
		
		// Change the scanner delimiter
		sc.useDelimiter(" ,|\r\n");
		
		while (sc.hasNext()) {
			
			
			int customerID = Integer.parseInt(sc.next().trim());
			String fName = sc.next().trim();
			String lName = sc.next().trim();
			int status = Integer.parseInt(sc.next());
			int bill = Integer.parseInt(sc.next().trim());
			int month = Integer.parseInt(sc.next().trim());
			double kwh = Double.parseDouble(sc.next().trim());
			
			// call 
			
			addCustomer(customerID,fName,lName,status,bill,month,kwh);
		}// end while
		
		sc.close();
		
		JOptionPane.showMessageDialog(null,"Done Reading from file!");
	}// end readFromFile


//int customerID, String fName, String lName, int status, ElectricBill bill
private static void addCustomer(int customerID, String fName, String lName, int status,int bill,int month,double kwh) {
	for(int i = 0; i<= getFileLength("customers2.txt");i++)
	if (status == 1)
	customers[i] = new Customer(customerID,fName,lName,status,bill,month,kwh);
	else 
		customers[i] = new Customer(customerID,fName,lName,status,bill,month,kwh);
}

	private void initComponenet(){
		// intialize the GUI components
		  label1 = new JLabel("First Name");
	      label2 = new JLabel("Last Name:");
	      label3 = new JLabel("Customer ID:");
	      label4 = new JLabel("Energy (kWH):");
	      field1 = new JTextField(15);
	      field2 = new JTextField(15);
	      field3 = new JTextField(15);
	      field4 = new JTextField(15);
	      field5 = new JTextField(25);
	      
	      String[] customerType = { "","Residential", "Commercial"};
	      customerList = new JComboBox(customerType);
	      String[] month = { "","Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};
	      monthList = new JComboBox(month);
	      SubmitButton = new JButton("Submit");
	      CloseButton = new JButton("Close");
	      field1.setEditable(true);
	      field2.setEditable(true);
	      field3.setEditable(true);
	      field4.setEditable(true);
	      field5.setEditable(false);
		  
	}

   private void doTheLayout(){
		// Organize the components into GUI window
	   JPanel top = new JPanel();
	      JPanel center = new JPanel();
	      JPanel bottom = new JPanel();

	      top.setLayout( new FlowLayout());
	      top.add(label1);
	      top.add(field1);
	      top.add(label2);
	      top.add(field2);
	      
	      
	      //center.setLayout( new GridLayout(3,3));
	      bottom.setLayout( new FlowLayout());
	      center.add(label3);
	      center.add(field3);
	      center.add(customerList);
	      center.add(label4);
	      center.add(field4);
	      center.add(monthList);
	      //center.setPreferredSize( new Dimension( 10, 15 ) );
	      center.add(SubmitButton);
	      center.add(CloseButton);
	      
	      
	      
	      bottom.setLayout( new GridLayout(1,1));
	      
	      bottom.add(field5);
	   
	      this.add(top, "North");
	      this.add(center, "Center");
	      this.add(bottom, "South");
	}
   public Customer transfer(){
       String fName = field1.getText();
       String lName = field2.getText();
       int customerID = Integer.parseInt(field3.getText()); 
       int kwh = Integer.parseInt(field4.getText()); 
       String month = monthList.getSelectedItem().toString();
       String statusstr = customerList.getSelectedItem().toString();
       int status = 0;
       int monthNum = 0;
       if(customerList.getSelectedItem().toString().contentEquals("Commercial")) {
    	   status = 0;
       }else if(customerList.getSelectedItem().toString().contentEquals("Residential")){
    	   status = 1;
       }
       switch(month) {
		case "Jan":
			monthNum = 1;
			break;
		case "Feb":
			monthNum = 2;
			break;
		case "Mar":
			monthNum = 3;
			break;
		case "Apr":
			monthNum = 4;
			break;
		case "May":
			monthNum = 5;
			break;
		case "Jun":
			monthNum = 6;
			break;
		case "Jul":
			monthNum = 7;
			break;
		case "Aug":
			monthNum = 8;
			break;
		case "Sep":
			monthNum = 9;
			break;
		case "Oct":
			monthNum = 10;
			break;
		case "Nov":
			monthNum = 11;
			break;
		case "Dec":
			monthNum = 12;
			break;
		}
       
       
       System.out.println(customerID + fName + lName + status + kwh + " " + monthNum);
	return new Customer(customerID,fName,lName,status,monthNum,kwh);
       
       
 }

	@Override
	public void actionPerformed(ActionEvent event) {
		//call appropriate methods as required based on user actions
		if (event.getSource() == this.CloseButton)
		this.closeButtonClicked();
		else if (event.getSource() == this.SubmitButton)
		this.submitButtonClicked();
		}

	private void submitButtonClicked(){
		// code to be executed once the submit button is clicked
		//add customer object to the customers[] array
		//display the customer objects followed by sum and average
		customers[customers.length-1] = transfer();
		String output = Customer.tostring();
        field5.setText(output);
//		if (status == 1)
//			customers[i] = new Customer(customerID,fName,lName,status,new Commercial(kwh,billMonth));
//			else 
//				customers[i] = new Customer(customerID,fName,lName,status,new Residential(kwh,billMonth));
//		
		
	}

	private void closeButtonClicked(){
		// code to be executed once the close button is clicked
		//write sorted output to file
		field5.setText("Goodbye!");
		System.exit(0);
	    
		
		// It must show a goodbye message and terminate the program

	}


	@Override
	public String toString() {
		return "UserGUI [field1=" + field1 + ", field2=" + field2 + ", field3=" + field3 + ", field4=" + field4
				+ ", field5=" + field5 + ", customerList=" + customerList + ", monthList=" + monthList + "]";
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		UserGUI frame = new UserGUI("customers2.txt");
		frame.setSize(900,300);
	    frame.setTitle("User GUI");
	    //frame.pack();
	    frame.setLocationRelativeTo(null); // Center the frame
	    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    frame.setVisible(true);
	    

	}

}

